# Test Golang Build

Test repo for working on github actions.